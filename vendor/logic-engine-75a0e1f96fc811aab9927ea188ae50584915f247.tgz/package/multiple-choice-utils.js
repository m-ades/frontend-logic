/*
returns the first populated subquestion array from current or legacy fields
preserves order without mutation and returns an empty array for standalone questions
missing or nonarray fields are ignored
*/
export function getCompositeSubquestions(question) {
  for (const subquestions of [question?.subquestions, question?.questions]) {
    if (Array.isArray(subquestions) && subquestions.length > 0) return subquestions
  }
  return []
}

export const hasNonEmptyAnswerIndices = (subq) => (
  Array.isArray(subq?.answerIndices) && subq.answerIndices.length > 0
)

/*
resolves a standalone question's answer key checking nested fields before top level ones
a nonempty answer list beats any single index so a stale answerIndex beside it is ignored
*/
export function getStandaloneAnswerKey(question) {
  const nested = question?.multipleChoice
  if (hasNonEmptyAnswerIndices(nested)) return nested.answerIndices
  const nestedSingle = nested?.answerIndex ?? nested?.correctIndex
  if (nestedSingle != null) return nestedSingle
  if (hasNonEmptyAnswerIndices(question)) return question.answerIndices
  return question?.answerIndex ?? question?.answer
}

export const isMultiSelectSubquestion = (subq) => (
  subq?.type === 'multi-select'
  || Boolean(subq?.multiSelect)
  || hasNonEmptyAnswerIndices(subq)
)

// keeps the distinct choice indexes that point at a real choice, in their original order
export function normalizeAnswerIndices(values, choiceCount) {
  const indices = (Array.isArray(values) ? values : [values])
    .filter((entry) => entry !== '' && entry != null)
    .map(Number)
    .filter((index) => Number.isInteger(index) && index >= 0 && index < choiceCount)
  return [...new Set(indices)]
}

// restores a scalar or array selection to the shape isMultiSelectSubquestion expects
export function normalizeSubquestionSelection(subq, value) {
  const indices = normalizeAnswerIndices(value, getSubquestionChoices(subq).length)
  return isMultiSelectSubquestion(subq) ? indices : (indices[0] ?? '')
}

const trueFalseChoices = Object.freeze(['True', 'False'])

/*
purpose preserves legacy true false subquestions inside multiple choice
contract supplies visible choices and the selected answer index
invariant true is index zero and false is index one
error behavior invalid answers have no selected index
*/
export function getSubquestionChoices(subq) {
  if (Array.isArray(subq?.choices) && subq.choices.length > 0) return subq.choices
  return subq?.type === 'true-false' ? trueFalseChoices : []
}

export function getSingleSelectAnswerIndex(subq) {
  const raw = subq?.answerIndex
    ?? (Array.isArray(subq?.answerIndices) ? subq.answerIndices[0] : undefined)
    ?? subq?.answer
  if (subq?.type === 'true-false') {
    if (raw === true || raw === 'true' || raw === 'T' || raw === 't') return 0
    if (raw === false || raw === 'false' || raw === 'F' || raw === 'f') return 1
  }
  if (raw == null || raw === '') return null
  const index = Number(raw)
  return Number.isFinite(index) ? index : null
}
