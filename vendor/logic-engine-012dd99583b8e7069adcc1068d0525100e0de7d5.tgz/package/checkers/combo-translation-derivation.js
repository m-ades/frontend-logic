// LICENSE: GNU GPL v3 You should have received a copy of the GNU General
// Public License along with this program. If not, see
// https://www.gnu.org/licenses/.

////////////// checkers/combo-translation-derivation.js ////////////////
// combines translation checking with a derivation check              //
////////////////////////////////////////////////////////////////////////

import { componentScorePercent } from './component-grading.js';
import tr from '../translate.js';
import { getDerivationCheckerForLogicSystem } from './derivation-by-logic-system.js';
import getFormulaClass from '../symbolic/formula.js';
import { equivtest } from '../symbolic/libequivalence.js';
import { parseArgumentLine, resolveExpectedArgument } from '../argumentLine.js';

let defaultnotation = 'cambridge';
if ((typeof process !== 'undefined') && process?.appsettings?.defaultnotation) {
    defaultnotation = process.appsettings.defaultnotation;
}

export default async function(
    question, answer, givenans, partialcredit, cheat, options
) {
    let notation = defaultnotation;
    if (options?.notation) {
        notation = options.notation;
    }
    const Formula = getFormulaClass(notation);
    let correct = true;
    const messages = [];
    let derivErrors = null;
    const expectedArg = resolveExpectedArgument(answer);
    const expectedTransCount = ((expectedArg?.premises?.length ?? 0) + (expectedArg?.conclusion ? 1 : 0)) || 1;
    const transTtl = expectedTransCount;
    let derivationScore = 0;
    let transEarned = 0;

    const expected = expectedArg;
    if (expected.error) {
        correct = false;
        messages.push(expected.error);
    }

    const givenLine = givenans?.argumentLine ?? givenans?.argument ?? '';
    const given = parseArgumentLine(givenLine);
    if (given.error) {
        correct = false;
        messages.push(given.error);
    } else if (!expected.error) {
        const compareFormulas = (expStr, givenStr, indexLabel) => {
            try {
                const exp = Formula.from(expStr);
                const giv = Formula.from(givenStr);
                if (exp.normal === giv.normal) {
                    return { ok: true };
                }
                const eq = equivtest(exp, giv, notation);
                if (eq?.determinate) {
                    if (eq.equiv) {
                        return { ok: true };
                    }
                    return { ok: false, message: tr(`The ${indexLabel} is not equivalent to the expected translation.`) };
                }
                return { ok: false, message: tr(`Could not determine if the ${indexLabel} is equivalent to the expected translation.`) };
            } catch {
                return { ok: false, message: tr('The argument line contains an invalid formula.') };
            }
        };

        const usedGiven = new Set();
        const premiseMatches = expected.premises.map((expPrem, idx) => {
            for (let gIdx = 0; gIdx < given.premises.length; gIdx++) {
                if (usedGiven.has(gIdx)) continue;
                const res = compareFormulas(expPrem, given.premises[gIdx], tr(`premise ${idx + 1}`));
                if (res.ok) {
                    usedGiven.add(gIdx);
                    return { ok: true };
                }
            }
            return { ok: false };
        });

        for (const match of premiseMatches) {
            if (match.ok) {
                transEarned++;
            } else {
                correct = false;
                messages.push(tr('One or more premises are not equivalent to the expected translation.'));
            }
        }
        if (given.premises.length !== expected.premises.length) {
            correct = false;
            messages.push(tr('The number of premises does not match the expected argument.'));
        }

        const concResult = compareFormulas(expected.conclusion, given.conclusion, tr('conclusion'));
        if (concResult.ok) {
            transEarned++;
        } else {
            correct = false;
            if (concResult.message) {
                messages.push(concResult.message);
            }
        }
    }

    const providedProof = givenans?.proof
        ?? givenans?.derivationState?.ans
        ?? givenans?.derivationState
        ?? givenans?.ans
        ?? null;

    if (!given.error && providedProof) {
        const derivQuestion = {
            ...question,
            prems: given.premises,
            conc: given.conclusion,
        };
        const derivationChecker = getDerivationCheckerForLogicSystem(options?.logicSystem);
        const derivResult = await derivationChecker(
            derivQuestion,
            null,
            providedProof,
            partialcredit,
            cheat,
            options
        );
        if (derivResult.successstatus === 'correct') {
            derivationScore = 1;
        } else {
            correct = false;
            derivErrors = derivResult.errors || null;
            messages.push(tr('The derivation is not correct yet.'));
        }
    } else if (!providedProof) {
        correct = false;
        messages.push(tr('No derivation was submitted.'));
    }

    const translationScore = transTtl > 0 ? (transEarned / transTtl) : 0;

    const rv = {
        successstatus: (correct ? "correct" : "incorrect"),
        score: componentScorePercent([translationScore, derivationScore]),
        componentScores: [translationScore, derivationScore],
    };
    if (cheat) {
        rv.messages = messages;
        if (derivErrors) {
            rv.errors = derivErrors;
        }
    }
    return rv;
}
