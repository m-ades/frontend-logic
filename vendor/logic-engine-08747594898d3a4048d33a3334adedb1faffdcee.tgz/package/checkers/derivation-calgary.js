// LICENSE: GNU GPL v3 You should have received a copy of the GNU General
// Public License along with this program. If not, see
// https://www.gnu.org/licenses/.

///////////////// checkers/derivation-calgary.js /////////////////////
// calgary-specific derivation checker, uses derivation-check.js    //
//////////////////////////////////////////////////////////////////////

import getRules from './rules/forallx-rules.js';
import DerivationCheck from './derivation-check.js';
import { justParse } from '../justification-parse.js';
import getFormulaClass from '../symbolic/formula.js';
import { normalizeRuleSymbolName } from '../symbolic/libsyntax.js';
import {
    addRequiredRuleErrors,
    applyRuleFilters,
    getRulesetRestrictions,
} from './derivation-rule-restrictions.js';

// default notation from settings, but calgary otherwise
let defaultnotation = 'calgary';
if ((typeof process != "undefined") && (process?.appsettings?.defaultnotation)) {
    defaultnotation = process.appsettings.defaultnotation;
}

function normalizeRuleName(rule, notationname = defaultnotation) {
    if (!rule) return '';
    const syntax = getFormulaClass(notationname).syntax;
    const normalized = normalizeRuleSymbolName(rule, syntax);
    return DerivationCheck.ruleAliases?.[normalized] ||
        DerivationCheck.ruleAliases?.[rule] ||
        normalized;
}

// try to determine which lines are actual progress
function progresslinesin(deriv, errors, rules, notationname = defaultnotation) {
    let ttl = 0;
    // skip empty subderivations
    if (!("parts" in deriv)) { return 0; }
    for (let pt of deriv.parts) {
        // recursively apply to subdirevations
        if ("parts" in pt) {
            ttl+= progresslinesin(pt, errors, rules, notationname);
        }
        // skip lines without line numbers or justifications
        if ((!("n" in pt)) || (!("j" in pt))) {
            continue;
        }
        // lines with errors are not progress
        if (pt.n in errors) {
            let badfound = false;
            for (let cat in errors[pt.n]) {
                if (cat != 'dependency') {
                    badfound = true;
                    break;
                }
            }
            if (badfound) { continue; }
        }
        // determine kind of out rule
        const { nums, ranges, citedrules } = justParse(pt.j);
        if (citedrules.length < 1) { continue; }
        const rule = normalizeRuleName(citedrules[0], notationname);
        // skip nonexistent rules
        if (!(rule in rules)) {
            continue;
        }
        // do not premises, assumptions, in-rules to avoid cheese
        if (!(rules[rule].premiserule) &&
            !(rules[rule].assumptionrule) &&
            !(/I$/.test(rule))) {
            ttl++;
        }
    }
    return ttl;
}

export default async function(
    question, answer, givenans, partialcredit, cheat, options
) {
    // clone the answer to avoid messing it up when checking it
    const ansclone = JSON.parse(JSON.stringify(givenans));
    const notationname = (options?.notation ?? defaultnotation);
    const { allow, deny, require, requireAny } = getRulesetRestrictions(question, options);
    const normalizeForNotation = (rule) => normalizeRuleName(rule, notationname);
    const rules = applyRuleFilters(
        getRules('calgary', notationname),
        allow,
        deny,
        normalizeForNotation
    );
    const checkResult = new DerivationCheck(
        rules,
        ansclone,
        question.prems,
        question.conc,
        { notation: notationname, assumptionMode: 'nested' }
    ).report();
    addRequiredRuleErrors(checkResult, ansclone, require, requireAny, normalizeForNotation);
    // only correct if no errors
    const correct = (Object.keys(checkResult.errors).length == 0);
    let score = correct ? 100 : 0;
    // try to determine partial credit by checking progress vs needed
    // progress
    if (partialcredit && !correct) {
        // check number of good lines versus answer's good lines
        const goalprogress = progresslinesin(answer, {}, rules, notationname);
        const actualprogress = progresslinesin(givenans, checkResult.errors, rules, notationname);
        const progportion = (actualprogress / goalprogress);
        let portion = Math.min(actualprogress * 0.1, 0.5);
        // maximum of 0.8 for incomplete derivations
        if (progportion < 0.8) {
            portion = (portion * progportion);
        }
        score = Math.floor(portion * 100);
    }
    return {
        successstatus: (correct ? "correct" : "incorrect"),
        errors: checkResult.errors,
        score
    }
}
